package com.yuan.simple.one.multi;

import yuan.tools_extend.adapter.ExpandableItem;

/**
 * @author yuanye
 * @date 2018/12/19
 */
public class ItemBean extends ExpandableItem {
    public String name;

    public ItemBean(String name) {
        this.name = name;
    }
}
