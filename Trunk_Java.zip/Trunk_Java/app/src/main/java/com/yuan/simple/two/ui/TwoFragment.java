package com.yuan.simple.two.ui;

import android.os.Bundle;
import android.support.annotation.Nullable;

import com.yuan.simple.R;
import com.yuan.simple.one.BaseFragment;

/**
 * Created by YuanYe on 2018/4/13.
 */
public class TwoFragment extends BaseFragment {

    @Override
    public int getLayoutId() {
        return R.layout.frag_two_layout;
    }

    @Override
    public void findViews() {

    }

    @Override
    public void parseBundle(@Nullable Bundle bundle) {

    }

    @Override
    public void initData() {

    }

    @Override
    public void setListener() {

    }

}
