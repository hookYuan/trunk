package com.yuan.autobuild;

import com.yuan.autobuild.copy.CopyManager;

public class MyClass {

    public static void main(String[] args) {
        //方法体
//        CopyManager.getInstance()
//                .addTask(new JavaManagerCopy())
//                .autoBuild();
//        System.out.print(JavaManager.class.getResource("").getPath());
//        System.out.print(System.getProperty("user.dir") +
//                "\\autoBuild" + "\\java\\main\\com\\yuan\\autobuild\\javabuild\\JavaManager.java");
    }
}
