package com.yuan.autobuild.javabuild;

import com.squareup.javapoet.MethodSpec;
import com.squareup.javapoet.TypeSpec;

import java.util.List;

/**
 * @author yuanye
 * @date 2019/6/24
 */
public class ActivityAutoBuild implements IAutoBuild {

    @Override
    public List<MethodSpec> getMethodSpecs() {

        return null;
    }

    @Override
    public TypeSpec.Builder getTypeSpec(String className) {

        return null;
    }

    @Override
    public AutoInfo getAutoInfo() {

        return null;
    }
}
