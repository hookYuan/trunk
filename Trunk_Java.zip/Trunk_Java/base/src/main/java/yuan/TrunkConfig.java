package yuan;

/**
 * Created by wanglei on 2016/12/4.
 */

public class TrunkConfig {

    /******************************* 缓存相关设置 (缓存父目录为Android/data)************************************/
    // #cache  自定义缓存文件名
    public static final String CACHE_DISK_DIR = "cache";

}
